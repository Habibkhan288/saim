---
title: What is Hacker101?
---

Hacker101 is a free educational resource developed by [HackerOne](https://www.hackerone.com/) to grow and empower the hacker community at large.  We have video lessons and curated resources to help you learn the concepts of hacking and a [Capture the Flag](https://ctf.hacker101.com/) where you can turn that theory into practice.
