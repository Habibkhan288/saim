---
title: What is the Hacker101 CTF?
---

The [Hacker101 CTF](https://ctf.hacker101.com/) -- or Capture the Flag -- is a game where you hack through levels to find bits of data called flags.  These flags mark your progress and allow you to receive invitations to private programs on [HackerOne](https://www.hackerone.com/), where you can use your newly-learned skills.
